# ROI SHAPE (roishapeclaude)

App fitness para personal trainers, alunos e gestores. Site estático (sem build) conectado ao
Supabase **Roishapecloud** (login, banco e regras de acesso por linha).

## O que já funciona
- Login com Google (principal). E-mail e senha ficam só como alternativa para contas antigas. Primeiro acesso: escolha entre Aluno e Personal e, para alunos, o código do personal.
- **Aluno:** treino do dia por blocos (Ênfase e Complemento), repetições por série, bi-set A1/A2 sem descanso, cronômetro, progresso, histórico, avaliações e biomecânica.
- **Personal:** cartões de alunos com atalhos (Fullbody oficial, nova ficha, avaliação), montagem de fichas, avaliações, biomecânica e biblioteca com 41 exercícios.
- **Fullbody oficial (Método ROI SHAPE):** modelo publicado no banco (tabela `workout_models`, versão 1: ênfase em membros inferiores). O personal atribui com um toque; as cargas ficam em branco. Só o admin publica novas versões.
- **Admin:** usuários (perfil e ativação), vínculos personal–aluno, biblioteca.

- **Vídeos:** o personal cadastra o próprio link do YouTube por exercício ("Meu vídeo"), que os alunos vinculados a ele veem. O admin cadastra o vídeo oficial ("Vídeo oficial"). Sem vídeo, o app abre uma busca no YouTube.
- **Painel do personal:** indicadores, gráfico semanal de treinos dos alunos e lista de alunos parados com botão de WhatsApp (usa o telefone informado no primeiro acesso).
- **Marketing:** lançamentos manuais de campanhas (investimento, impressões, cliques, leads, conversões, receita) com custo por lead, custo por conversão, ROI e CTR. Sem conexão automática com plataformas de anúncios.

## Checklist de lançamento
1. Subir o zip no Netlify e conferir o endereço em Site URL e Redirect URLs do Supabase.
2. Ligar o login com Google (Client ID e Secret criados no Google Cloud) e publicar a tela de consentimento.
3. Entrar como Personal e como Aluno, fazer o ciclo: vínculo, ficha, treino, avaliação.
4. Olhar o console do navegador por avisos de CSP e, se não houver, ativar a política de verdade.
5. Publicar termos de uso e política de privacidade (dados de saúde: LGPD).

## Ainda pendente
- Tela do admin para publicar novas versões de modelos, edição/duplicação de fichas e histórico de alterações no app conectado.
- Figura anatômica realista na biomecânica (hoje é uma silhueta estilizada), funil CRM, planos e assinaturas, conexão automática com Meta/Google Ads, exercícios próprios do personal.
- Convite de aluno pelo próprio personal (hoje o vínculo é criado pelo admin).
- Testes automatizados de permissões.

## Publicar no GitHub
```bash
git add .
git commit -m "App conectado ao Supabase"
git push
```

## Hospedar (site estático)
Vercel ou Netlify: importe o repositório, sem comando de build, pasta de publicação = raiz (`/`).

## Configurar o Supabase (painel do projeto Roishapecloud)
1. Authentication > URL Configuration: defina **Site URL** com o endereço publicado e adicione o mesmo endereço em **Redirect URLs**.
2. Authentication > Providers > Google: ative, cole o Client ID e o Client Secret criados no Google Cloud Console (URI de redirecionamento: https://dnjvwgrbykqjxohjkwlt.supabase.co/auth/v1/callback). Nunca publique o Client Secret no repositório.
3. Primeiro admin: cadastre-se no app e peça a promoção (ou rode no SQL Editor):
   `update public.profiles set role = 'admin' where email = 'SEU_EMAIL';`

## Segurança
- `js/config.js` contém só a chave **publicável** (feita para o navegador). Os dados são protegidos pelas regras RLS do banco.
- Nunca coloque a chave `service_role` nem senhas neste repositório.
- Avaliações físicas são dados de saúde: o admin não as lê individualmente.

## Segurança de cabeçalhos (Netlify)
O arquivo `_headers` aplica cabeçalhos de segurança. A política de conteúdo (CSP) está em modo **somente relatório**:
abra o app no navegador, veja o console por avisos de CSP e, se não houver nenhum, troque
`Content-Security-Policy-Report-Only` por `Content-Security-Policy` e publique de novo.

## Modo de teste (superadmin)
A conta marcada como superadmin no banco vê um seletor "Modo" no topo para alternar entre Admin, Personal e Aluno.
Remova essa marca antes do lançamento, se não quiser esse recurso em produção.

## Biomecânica com imagens anatômicas
A aba Corpo usa duas imagens anatômicas (frente e costas) com áreas clicáveis em SVG sobre cada músculo.
As áreas são aproximadas. Confirme que você tem direito de uso das imagens antes de publicar.
Não há versão feminina, porque não há imagem feminina no projeto.

## Vídeos
- O aluno assiste ao vídeo dentro do treino (YouTube sem rastreio, carregado só ao tocar).
- Admin: Biblioteca > "Importar vídeos oficiais em lote" (uma linha por exercício: `nome;link`).
- Personal: "Meu vídeo" em cada exercício.
