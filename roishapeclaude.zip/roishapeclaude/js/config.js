// Chave PUBLICÁVEL do Supabase: feita para ficar no navegador. A proteção dos dados vem das
// regras de acesso por linha (RLS) do banco. NUNCA coloque aqui a chave service_role ou senhas.
export const SUPABASE_URL = 'https://dnjvwgrbykqjxohjkwlt.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_AncOIq0_Bah3PnyHiPPueQ_vIUMVOee';
// Troque para true somente depois de ligar o Google em Authentication > Providers no Supabase.
export const GOOGLE_LOGIN = false;
// Responsável técnico exibido no app, nos Termos e na Política. O crédito só aparece quando "cref" estiver preenchido.
// Exemplo de formato: '000000-G/UF'
export const RESP_TECNICO = {nome: 'Phillip Sarraff', cref: '140648-G/SP'};
