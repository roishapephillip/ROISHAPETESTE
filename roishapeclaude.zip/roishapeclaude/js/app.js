import {createClient} from 'https://esm.sh/@supabase/supabase-js@2.45.4';
import {SUPABASE_URL, SUPABASE_KEY, GOOGLE_LOGIN, RESP_TECNICO} from './config.js';

const sb = createClient(SUPABASE_URL, SUPABASE_KEY);
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => '&#' + c.charCodeAt(0) + ';');
const G = {peito:'Peitoral',ombros:'Ombros',biceps:'Bíceps',triceps:'Tríceps',antebraco:'Antebraço',abdomen:'Abdômen',quadriceps:'Quadríceps',trapezio:'Trapézio',dorsais:'Dorsais',lombar:'Lombar',gluteos:'Glúteos',posteriores:'Posteriores de coxa',panturrilhas:'Panturrilhas'};
const BRAND = big => `<div class="brand${big ? ' big' : ''}"><img src="assets/logo-192.webp" width="${big ? 96 : 40}" height="${big ? 96 : 40}" alt="Logotipo ROI SHAPE"><div class="logo">ROI <b>SHAPE</b></div></div>`;
const CREDITO = () => RESP_TECNICO.cref ? `<p class="muted" style="font-size:12px;text-align:center;margin:10px 16px">Método ROI SHAPE idealizado por ${esc(RESP_TECNICO.nome)}, responsável técnico · Profissional de Educação Física · CREF ${esc(RESP_TECNICO.cref)} · <a href="https://www.confef.org.br/" target="_blank" rel="noopener">Consultar registro</a></p>` : '';
const BLOCO = {enfase: 'Bloco 1 — Ênfase', complemento: 'Bloco 2 — Complemento', livre: 'Treino'};
const ROLE = {aluno:'Aluno', personal:'Personal', admin:'Admin'};
const TABS = {
  aluno:[['hoje','Hoje'],['corpo','Corpo'],['evol','Evolução']],
  personal:[['painel','Painel'],['alunos','Alunos'],['ficha','Fichas'],['corpo','Corpo'],['mkt','Marketing'],['lib','Biblioteca']],
  admin:[['usu','Usuários'],['vinc','Vínculos'],['mkt','Marketing'],['lib','Biblioteca']]};
const CONV = (new URLSearchParams(location.search).get('convite') || (() => {try {return localStorage.getItem('convite')} catch (e) {return ''}})() || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
let me = null, tab = '', cur = null, B = null, EX = [], T = {l:0, i:0};

function toast(m){const t=$('#toast');t.textContent=m;t.className='on';clearTimeout(toast.t);toast.t=setTimeout(()=>t.className='',3000)}
const run = async (q, msg) => {const {data, error} = await q; if (error) {toast(msg || 'Erro: ' + error.message); throw error} return data};
let PV = {};
const ytId = v => {const t = String(v || '').trim(); if (/^[A-Za-z0-9_-]{11}$/.test(t)) return t; const m = t.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/))([A-Za-z0-9_-]{11})/); return m ? m[1] : null};
const vidBtn = (e, i) => {const id = PV[e.id] || e.youtube_id; return id ? `<button class="btn g s" data-a="play" data-v="${id}" data-i="${i}">▶ Vídeo</button>` : `<a class="btn g s" href="${yt(e)}" target="_blank" rel="noopener">Buscar vídeo</a>`};
let WT = {t0: 0, i: 0};
const wtTick = () => {const el = $('#wt'); if (!el) {clearInterval(WT.i); return} const s = Math.floor((Date.now() - WT.t0) / 1000); el.textContent = 'Tempo ' + String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0')};
const hasVid = e => !!(PV[e.id] || e.youtube_id);
const yt = e => {const id = PV[e.id] || e.youtube_id; return id ? 'https://www.youtube.com/watch?v=' + id : 'https://www.youtube.com/results?search_query=' + encodeURIComponent('como fazer ' + e.nome + ' execução correta')};
async function loadPV() {
  PV = {};
  if (me.role != 'aluno' && me.role != 'personal') return;
  try {
    let q = sb.from('personal_videos').select('exercise_id,youtube_id'); if (me.role == 'personal') q = q.eq('personal_id', me.id);
    const r = await run(q); PV = Object.fromEntries(r.map(x => [x.exercise_id, x.youtube_id]));
  } catch (e) {PV = {}}
}
const stat = (n, l) => `<div class="card stat"><b>${n}</b>${l}</div>`;
const bars = (v, lab) => {const m = Math.max(1, ...v); return `<div class="bars">${v.map((x, i) => `<div class="bcol"><span>${x}</span><div style="height:${Math.max(4, x / m * 100)}px"></div><small>${lab[i]}</small></div>`).join('')}</div>`};
const wa = a => {const t = String(a.telefone || ''); if (!t) return '<span class="tag">sem telefone</span>'; const num = t.length <= 11 ? '55' + t : t; return `<a class="btn s" href="https://wa.me/${num}?text=${encodeURIComponent('Oi ' + a.nome.split(' ')[0] + ', notei que você não treinou nesta semana. Bora retomar?')}" target="_blank" rel="noopener">WhatsApp</a>`};
const BRL = n => Number(n).toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'});
const empty = (t, p) => `<div class="card"><h3>${t}</h3><p class="muted">${p}</p></div>`;
const det = e => `<details style="margin-top:6px"><summary class="muted" style="cursor:pointer">Execução e cuidados</summary><p style="margin-top:6px"><b>Principal:</b> ${G[e.grupo_principal]||''}${(e.exercise_muscles||[]).filter(m=>m.tipo=='secundario').length?`<br><b>Secundários:</b> ${e.exercise_muscles.filter(m=>m.tipo=='secundario').map(m=>G[m.musculo]).join(', ')}`:''}<br><b>Execução:</b> ${esc(e.execucao)}<br><b>Cuidado:</b> ${esc(e.cuidado)}<br><small class="muted">Orientação geral: o personal ajusta ao aluno.</small></p></details>`;
const num = v => v === '' || v == null ? null : +String(v).replace(',', '.');

/* ---------- Autenticação ---------- */
function authView(msg = '', mode = 'in') {
  const up = mode == 'up', reset = mode == 'reset', t = up ? 'Criar conta' : reset ? 'Recuperar senha' : 'Entrar';
  $('#app').innerHTML = `<div class="auth">${BRAND(true)}<p class="muted">Treino inteligente, resultados reais.</p><form class="card" data-f="auth" data-mode="${mode}"><h2>${t}</h2>
  ${GOOGLE_LOGIN && !reset ? '<button type="button" class="btn" style="width:100%" data-a="google">Continuar com Google</button><p class="muted" style="text-align:center;margin:10px 0">ou</p>' : ''}
  ${up ? `<label>Nome</label><input name="nome" autocomplete="name"><label>Eu sou</label><select name="perfil"><option value="aluno">Aluno</option><option value="personal">Personal trainer</option></select><label>Código do seu personal (somente alunos)</label><input name="convite" value="${esc(CONV)}" autocapitalize="characters" autocomplete="off" placeholder="Opcional">` : ''}
  <label>E-mail</label><input name="email" type="email" autocomplete="email" inputmode="email">
  ${reset ? '' : `<label>Senha${up ? ' (mínimo 8 caracteres)' : ''}</label><input name="senha" type="password" autocomplete="${up ? 'new-password' : 'current-password'}"><label style="display:flex;gap:8px;align-items:center;margin-top:8px"><input type="checkbox" id="showpw" style="width:auto"> Mostrar senha</label>`}
  ${up ? `<label style="display:flex;gap:8px;align-items:flex-start;margin-top:12px"><input type="checkbox" name="aceite" value="1" style="width:auto;margin-top:3px"><span>Li e aceito os <a href="termos.html" target="_blank" rel="noopener">Termos de Uso</a> e a <a href="privacidade.html" target="_blank" rel="noopener">Política de Privacidade</a>, inclusive o tratamento dos meus dados de saúde.</span></label>` : ''}<p class="err">${esc(msg)}</p><button class="btn" style="width:100%">${up ? 'Criar conta' : reset ? 'Enviar link' : 'Entrar'}</button>
  <div class="row" style="margin-top:12px;justify-content:space-between">${mode != 'in' ? '<a href="#" data-a="mode" data-v="in">Já tenho conta</a>' : '<a href="#" data-a="mode" data-v="up">Criar conta</a>'}${!reset ? '<a href="#" data-a="mode" data-v="reset">Esqueci a senha</a>' : ''}</div></form><p class="muted" style="font-size:12px;text-align:center;margin-top:16px">ROI SHAPE CONDICIONAMENTO FÍSICO LTDA · CNPJ 68.555.766/0001-76<br><a href="termos.html">Termos de Uso</a> · <a href="privacidade.html">Privacidade</a></p>${CREDITO()}</div>`;
}
function onboardView() {
  $('#app').innerHTML = `<div class="auth">${BRAND(true)}<form class="card" data-f="onboard"><h2>Bem-vindo, ${esc(me.nome.split(' ')[0])}!</h2><label>Eu sou</label><select name="perfil"><option value="aluno">Aluno</option><option value="personal">Personal trainer</option></select><label>Telefone com DDD (opcional)</label><input name="tel" inputmode="tel" autocomplete="tel" placeholder="11999999999"><label>Código do seu personal (somente alunos)</label><input name="convite" value="${esc(CONV)}" autocapitalize="characters" autocomplete="off" placeholder="Opcional"><label style="display:flex;gap:8px;align-items:flex-start;margin-top:12px"><input type="checkbox" name="aceite" value="1" style="width:auto;margin-top:3px"><span>Li e aceito os <a href="termos.html" target="_blank" rel="noopener">Termos de Uso</a> e a <a href="privacidade.html" target="_blank" rel="noopener">Política de Privacidade</a>, inclusive o tratamento dos meus dados de saúde.</span></label><p class="err"></p><button class="btn" style="width:100%">Continuar</button></form><button class="btn g s" style="margin-top:12px" data-a="out">Sair</button></div>`;
}
function recoveryView() {
  $('#app').innerHTML = `<div class="auth">${BRAND(true)}<form class="card" data-f="newpass"><h2>Nova senha</h2><label>Nova senha (mínimo 8 caracteres)</label><input name="senha" type="password" autocomplete="new-password"><p class="err"></p><button class="btn" style="width:100%">Salvar senha</button></form></div>`;
}
const F = {
  async vidlote(d, f) {
    const err = f.querySelector('.err'), norm = t => String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
    const lines = String(d.lista || '').split('\n').map(l => l.trim()).filter(Boolean);
    if (!lines.length) return err.textContent = 'Cole ao menos uma linha.';
    await loadEx(); const ok = [], bad = [];
    for (const l of lines) {
      const i = l.lastIndexOf(';'), nm = i < 0 ? '' : l.slice(0, i), id = ytId(i < 0 ? '' : l.slice(i + 1)), e = EX.find(x => norm(x.nome) == norm(nm));
      if (!e || !id) {bad.push(l.slice(0, 40)); continue}
      ok.push({e, id});
    }
    for (const {e, id} of ok) {const r = await run(sb.from('exercises').update({youtube_id: id}).eq('id', e.id).select('id')); if (r.length) e.youtube_id = id}
    err.textContent = bad.length ? 'Não reconhecidas (' + bad.length + '): ' + bad.join(' | ') : '';
    toast(ok.length + ' vídeo(s) importado(s)'); const el = $('#exl'); if (el) el.innerHTML = exl();
  },
  async mkt(d, f) {
    const err = f.querySelector('.err'), n = k => d[k] === '' || d[k] == null ? 0 : num(d[k]);
    const v = {investimento: n('investimento'), impressoes: n('impressoes'), cliques: n('cliques'), leads: n('leads'), conversoes: n('conversoes'), receita: n('receita')};
    if (!d.data) return err.textContent = 'Informe a data.';
    if (Object.values(v).some(x => !Number.isFinite(x) || x < 0)) return err.textContent = 'Use apenas números positivos.';
    if (['impressoes', 'cliques', 'leads', 'conversoes'].some(k => !Number.isInteger(v[k]))) return err.textContent = 'Impressões, cliques, leads e conversões devem ser números inteiros.';
    if (!v.investimento && !v.leads && !v.receita) return err.textContent = 'Informe ao menos investimento, leads ou receita.';
    await run(sb.from('marketing_entries').insert({dono_id: me.id, data: d.data, canal: d.canal, ...v, observacao: (d.obs || '').trim().slice(0, 200) || null}));
    toast('Lançamento salvo'); view();
  },
  async auth(d, f) {
    const m = f.dataset.mode, err = f.querySelector('.err'), btn = f.querySelector('button:not([type="button"])'), email = (d.email || '').trim();
    err.textContent = '';
    if (!/^\S+@\S+\.\S+$/.test(email)) return err.textContent = 'Informe um e-mail válido.';
    if (m == 'up' && (d.nome || '').trim().length < 2) return err.textContent = 'Informe seu nome.';
    if (m == 'up' && !d.aceite) return err.textContent = 'Aceite os Termos e a Política de Privacidade para criar a conta.';
    if (m != 'reset' && (d.senha || '').length < (m == 'up' ? 8 : 1)) return err.textContent = m == 'up' ? 'A senha precisa ter ao menos 8 caracteres.' : 'Informe a senha.';
    btn.disabled = true;
    try {
      if (m == 'reset') {const {error} = await sb.auth.resetPasswordForEmail(email, {redirectTo: location.origin}); if (error) throw error; toast('Se o e-mail existir, enviamos o link de recuperação.')}
      else if (m == 'up') {const {data, error} = await sb.auth.signUp({email, password: d.senha, options: {data: {nome: d.nome.trim(), aceite: 'true', perfil: d.perfil === 'personal' ? 'personal' : 'aluno', convite: d.perfil === 'personal' ? '' : (d.convite || '').trim()}}}); if (error) throw error; if (!data.session) toast('Conta criada. Confirme o e-mail para entrar.')}
      else {const {error} = await sb.auth.signInWithPassword({email, password: d.senha}); if (error) throw error}
    } catch (e) {err.textContent = /Invalid login/i.test(e.message) ? 'E-mail ou senha incorretos.' : /rate limit/i.test(e.message) ? 'Limite de envio de e-mails atingido. Aguarde cerca de 1 hora e tente de novo.' : /not confirmed/i.test(e.message) ? 'Confirme seu e-mail antes de entrar (veja também o spam).' : /already registered/i.test(e.message) ? 'Este e-mail já tem conta. Toque em "Já tenho conta".' : e.message}
    btn.disabled = false;
  },
  async newpass(d, f) {
    const err = f.querySelector('.err');
    if ((d.senha || '').length < 8) return err.textContent = 'A senha precisa ter ao menos 8 caracteres.';
    const {error} = await sb.auth.updateUser({password: d.senha});
    if (error) return err.textContent = error.message;
    toast('Senha atualizada.'); const {data} = await sb.auth.getSession(); boot(data.session);
  },
  async aval(d, f) {
    const err = f.querySelector('.err'), p = num(d.peso), a = num(d.altura), g = num(d.gordura);
    if (!d.aluno) return err.textContent = 'Selecione o aluno.';
    if (p == null && a == null && g == null) return err.textContent = 'Informe ao menos uma medida.';
    if (p != null && !(p >= 20 && p <= 400)) return err.textContent = 'Peso deve estar entre 20 e 400 kg.';
    if (a != null && !(a >= 80 && a <= 250)) return err.textContent = 'Altura deve estar entre 80 e 250 cm.';
    if (g != null && !(g >= 2 && g <= 70)) return err.textContent = 'Gordura deve estar entre 2 e 70%.';
    await run(sb.from('assessments').insert({aluno_id: d.aluno, personal_id: me.id, peso: p, altura: a, gordura: g, observacao: (d.obs || '').trim() || null}));
    toast('Avaliação registrada'); view();
  },
  async convite(d, f) {
    const err = f.querySelector('.err'), c = (d.codigo || '').trim();
    if (c.length < 4) return err.textContent = 'Digite o código do seu personal.';
    const {data, error} = await sb.rpc('redeem_invite', {p_code: c});
    if (error) return err.textContent = error.message;
    if (!data) return err.textContent = 'Código não encontrado.';
    toast('Vinculado ao seu personal!'); view();
  },
  async onboard(d, f) {
    const err = f.querySelector('.err'), btn = f.querySelector('button'), per = d.perfil == 'personal' ? 'personal' : 'aluno';
    if (!d.aceite) return err.textContent = 'Aceite os Termos e a Política de Privacidade para continuar.';
    const tel = String(d.tel || '').replace(/\D/g, '');
    if (tel && !/^\d{10,13}$/.test(tel)) return err.textContent = 'Telefone inválido. Use DDD e número, só dígitos.';
    btn.disabled = true;
    const {data: up, error} = await sb.from('profiles').update({role: per, onboarded: true, telefone: tel || null, consentimento_em: new Date().toISOString()}).eq('id', me.id).select('*').single();
    if (error) {err.textContent = 'Não foi possível salvar: ' + error.message; btn.disabled = false; return}
    me = up;
    if (per == 'aluno' && (d.convite || '').trim()) {
      const {data: ok} = await sb.rpc('redeem_invite', {p_code: d.convite.trim()});
      if (!ok) toast('Código não encontrado. Você pode informá-lo depois na tela inicial.');
    }
    try {localStorage.removeItem('convite')} catch (e) {}
    tab = TABS[me.role][0][0]; shell();
  },
  async vinc(d, f) {
    const err = f.querySelector('.err');
    if (!d.personal || !d.aluno) return err.textContent = 'Selecione personal e aluno.';
    const {error} = await sb.from('trainer_students').insert({personal_id: d.personal, aluno_id: d.aluno});
    if (error) return err.textContent = error.code == '23505' ? 'Esse vínculo já existe.' : error.message;
    toast('Vínculo criado'); view();
  }
};

/* ---------- Estrutura ---------- */
async function boot(s) {
  if (!s) {me = null; return authView('', CONV ? 'up' : 'in')}
  if (me && me.id == s.user.id) return;
  $('#app').innerHTML = '<div class="sk" style="margin:24px"></div>';
  const {data: p, error} = await sb.from('profiles').select('*').eq('id', s.user.id).single();
  if (error || !p) {await sb.auth.signOut(); return authView('Não foi possível carregar seu perfil. Tente novamente.')}
  if (!p.ativo) {await sb.auth.signOut(); return authView('Conta desativada. Fale com o administrador.')}
  me = p; if (!p.onboarded) return onboardView(); tab = TABS[p.role][0][0]; shell();
}
async function shell() {
  $('#app').innerHTML = `<header class="top">${BRAND()}<div class="row">${me.superadmin ? `<select data-a="modo" aria-label="Modo de teste" style="width:auto;padding:5px 8px">${Object.entries(ROLE).map(([k, v]) => `<option value="${k}" ${k == me.role ? 'selected' : ''}>Modo: ${v}</option>`).join('')}</select>` : `<span class="tag n">${ROLE[me.role]}</span>`}<button class="btn g s" data-a="out">Sair</button></div></header>
  <div class="layout"><nav>${TABS[me.role].map(([k, n]) => `<button data-a="tab" data-v="${k}">${n}</button>`).join('')}</nav><main id="main"></main></div>${CREDITO()}<div id="tm" hidden></div>`;
  await loadPV();
  view();
}
async function view() {
  const m = $('#main'); m.innerHTML = '<div class="sk"></div><div class="sk"></div>';
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.v == tab));
  try {m.innerHTML = await V[tab]()} catch (e) {m.innerHTML = empty('Não foi possível carregar', 'Verifique sua conexão e tente novamente.')}
}
const mine = async () => {
  const ts = await run(sb.from('trainer_students').select('aluno_id').eq('personal_id', me.id).eq('ativo', true));
  return ts.length ? run(sb.from('profiles').select('id,nome,email,telefone').in('id', ts.map(t => t.aluno_id)).order('nome')) : [];
};
const opts = (L, sel) => '<option value="">Selecione</option>' + L.map(x => `<option value="${x.id}" ${x.id == sel ? 'selected' : ''}>${esc(x.nome)}</option>`).join('');

/* ---------- Telas ---------- */
const exl = () => {
  const q = ($('#q')?.value || '').toLowerCase(), g = $('#gf')?.value || '';
  return EX.filter(e => (!g || e.grupo_principal == g) && e.nome.toLowerCase().includes(q)).map(e => `<div class="card"><b>${esc(e.nome)}</b><p class="muted">${G[e.grupo_principal]} · ${esc(e.equipamento)} ${PV[e.id] ? '<span class="tag n">seu vídeo</span>' : e.youtube_id ? '<span class="tag n">vídeo oficial</span>' : ''}</p>${det(e)}<div class="row" style="margin-top:8px"><a class="btn g s" href="${yt(e)}" target="_blank" rel="noopener">${hasVid(e) ? 'Assistir' : 'Buscar vídeo'}</a>${me.role != 'aluno' ? `<button class="btn g s" data-a="vid" data-v="${e.id}">${me.role == 'admin' ? 'Vídeo oficial' : 'Meu vídeo'}</button>` : ''}</div></div>`).join('') || '<p class="muted">Nenhum exercício encontrado.</p>';
};
const loadEx = async () => {if (!EX.length) EX = await run(sb.from('exercises').select('id,nome,grupo_principal,equipamento,youtube_id,execucao,cuidado,exercise_muscles(musculo,tipo)').order('nome'))};
const ZONAS = {
  f: [['trapezio','40,15 60,15 66,20 34,20',0],['peito','34,22 49,22 49,29 40,29.5 34,27',1],['ombros','26,21 33,20 34,26 29,28 26,26',1],['biceps','22,28 29,29 28,38 20,39',1],['antebraco','18,39 26,39 18,50 12,51',1],['abdomen','40,31 60,31 59,45 41,45',0],['quadriceps','32,53 46,53 46,68 33,69',1],['panturrilhas','33,73 43,73 42,88 35,88',1]],
  b: [['trapezio','44,13 56,13 68,19 60,26 50,37 40,26 32,19',0],['ombros','19,21 30,19 31,25 26,28 19,27',1],['dorsais','32,29 45,34 49,40 41,44 34,39',1],['triceps','15,26 24,27 22,37 14,36',1],['antebraco','14,37 22,37 16,50 8,50',1],['lombar','41,40 59,40 57,46 43,46',0],['gluteos','31,46 49,46 49,54 32,55',1],['posteriores','32,56 48,56 46,69 34,70',1],['panturrilhas','29,72 42,72 40,84 32,85',1]]};
const ANAT = {ombros:'Deltoide',biceps:'Bíceps braquial',triceps:'Tríceps braquial',trapezio:'Trapézio',peito:'Peitoral maior',abdomen:'Reto abdominal',quadriceps:'Quadríceps',posteriores:'Posteriores da coxa',gluteos:'Glúteo máximo',panturrilhas:'Gastrocnêmio',dorsais:'Latíssimo do dorso',lombar:'Eretores da espinha',antebraco:'Flexores do antebraço'};
let bView = 'f', bMu = '';
const flip = p => p.split(' ').map(pt => {const [x, y] = pt.split(','); return (100 - x) + ',' + y}).join(' ');
function bodySvg() {
  const poly = ZONAS[bView].flatMap(([m, p, mir]) => (mir ? [p, flip(p)] : [p]).map(pts => `<polygon class="mu${m == bMu ? ' sel' : ''}" data-a="mu" data-v="${m}" tabindex="0" role="button" aria-label="${G[m]}" points="${pts}"><title>${G[m]}</title></polygon>`)).join('');
  const w = bView == 'f' ? 499 : 671, h = bView == 'f' ? 1086 : 1669;
  return `<div class="corpo" style="aspect-ratio:${w}/${h}"><img src="assets/corpo-${bView == 'f' ? 'frente' : 'costas'}.webp" alt="Corpo humano, vista ${bView == 'f' ? 'frontal' : 'posterior'}" width="${w}" height="${h}" decoding="async"><svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-label="Áreas musculares">${poly}</svg></div>`;
}
function corpoHtml() {
  const chips = [...new Set(ZONAS[bView].map(a => a[0]))].map(k => `<button class="btn s ${k == bMu ? '' : 'g'}" data-a="mu" data-v="${k}">${G[k]}</button>`).join('');
  const prin = EX.filter(e => e.grupo_principal == bMu), sec = EX.filter(e => e.exercise_muscles.some(m => m.musculo == bMu && m.tipo == 'secundario'));
  const row = (e, tag) => `<div style="padding:8px 0;border-bottom:1px solid var(--ln)"><div class="row" style="justify-content:space-between"><span><b>${esc(e.nome)}</b> <span class="tag">${tag}</span></span><span class="row"><a class="btn g s" href="${yt(e)}" target="_blank" rel="noopener">Vídeo</a>${me.role == 'personal' ? `<button class="btn s" data-a="addex" data-v="${e.id}">+ Ficha</button>` : ''}</span></div>${det(e)}</div>`;
  return `<h1>Biomecânica</h1><p class="muted">Toque em um músculo para ver os exercícios.</p><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));margin-top:10px"><div class="card" style="text-align:center"><div class="row" style="justify-content:center;margin-bottom:8px"><button class="btn s ${bView == 'f' ? '' : 'g'}" data-a="bview" data-v="f">Frente</button><button class="btn s ${bView == 'b' ? '' : 'g'}" data-a="bview" data-v="b">Costas</button></div>${bodySvg()}<div class="row" style="justify-content:center;margin-top:8px">${chips}</div></div><div class="card">${bMu ? `<h2>${G[bMu]}</h2><p class="muted">${ANAT[bMu] || ''}</p>${prin.map(e => row(e, 'principal')).join('')}${sec.map(e => row(e, 'secundário')).join('')}` : '<p class="muted">Nenhum músculo selecionado.</p>'}</div></div>`;
}
const V = {
  async painel() {
    const L = await mine(), ids = L.map(x => x.id), W = 6048e5;
    const [logs, pls] = ids.length ? await Promise.all([
      run(sb.from('workout_logs').select('aluno_id,concluido_em').in('aluno_id', ids).gte('concluido_em', new Date(Date.now() - 42 * 864e5).toISOString())),
      run(sb.from('plans').select('aluno_id').in('aluno_id', ids))]) : [[], []];
    const sem = logs.filter(l => Date.now() - new Date(l.concluido_em) < W).length;
    const parados = L.filter(a => !logs.some(l => l.aluno_id == a.id && Date.now() - new Date(l.concluido_em) < W));
    const semFicha = L.filter(a => !pls.some(p => p.aluno_id == a.id)).length;
    const wk = [5, 4, 3, 2, 1, 0].map(w => logs.filter(l => {const t = Date.now() - new Date(l.concluido_em); return t >= w * W && t < (w + 1) * W}).length);
    return `<h1>Painel</h1><div class="grid" style="margin:12px 0">${stat(L.length, 'alunos vinculados')}${stat(sem, 'treinos em 7 dias')}${stat(parados.length, 'sem treinar há 7 dias')}${stat(semFicha, 'sem ficha')}</div><div class="card"><p class="muted">Treinos dos seus alunos por semana</p>${bars(wk, ['-5s', '-4s', '-3s', '-2s', '-1s', 'Esta'])}</div><h2>Precisam de atenção</h2>` +
      (L.length ? (parados.length ? '<div class="list">' + parados.map(a => `<div class="card row" style="justify-content:space-between"><span><b>${esc(a.nome)}</b><br><small class="muted">sem treino nos últimos 7 dias</small></span>${wa(a)}</div>`).join('') + '</div>' : '<p class="muted">Nenhum aluno parado. Bom trabalho!</p>') : empty('Comece convidando alunos', 'Use seu código de convite na aba Alunos.'));
  },
  async mkt() {
    const L = await run(sb.from('marketing_entries').select('*').order('data', {ascending: false}).limit(300));
    const sum = k => L.reduce((a, x) => a + Number(x[k] || 0), 0), inv = sum('investimento'), rec = sum('receita'), leads = sum('leads'), conv = sum('conversoes'), cl = sum('cliques'), imp = sum('impressoes');
    const dv = (a, b, f) => b > 0 ? f(a / b) : '—', pc = n => n.toLocaleString('pt-BR', {maximumFractionDigits: 1}) + '%';
    const meses = [...Array(6)].map((_, i) => {const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - (5 - i)); return d.toISOString().slice(0, 7)});
    const mm = k => meses.map(m => L.filter(x => x.data.slice(0, 7) == m).reduce((a, x) => a + Number(x[k]), 0)), lab = meses.map(m => m.slice(5) + '/' + m.slice(2, 4));
    const CAN = {meta: 'Meta (Instagram/Facebook)', google: 'Google Ads', tiktok: 'TikTok', indicacao: 'Indicação', organico: 'Orgânico', outro: 'Outro'};
    return `<h1>Marketing</h1><p class="muted" style="margin:6px 0 12px">Lançamentos manuais, com os números reais das suas campanhas. A conexão automática com Meta e Google Ads exige autorização das plataformas e ainda não existe.</p>
    <div class="grid">${stat(BRL(inv), 'investido')}${stat(BRL(rec), 'receita')}${stat(leads, 'leads')}${stat(dv(inv, leads, BRL), 'custo por lead')}${stat(conv, 'conversões')}${stat(dv(inv, conv, BRL), 'custo por conversão')}${stat(inv > 0 ? pc((rec - inv) / inv * 100) : '—', 'retorno (ROI)')}${stat(dv(cl * 100, imp, pc), 'CTR')}</div>
    <div class="grid" style="margin-top:12px"><div class="card"><p class="muted">Investimento por mês</p>${bars(mm('investimento').map(Math.round), lab)}</div><div class="card"><p class="muted">Receita por mês</p>${bars(mm('receita').map(Math.round), lab)}</div></div>
    <h2>Novo lançamento</h2><form class="card" data-f="mkt"><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr))"><div><label>Data</label><input name="data" type="date" value="${new Date().toISOString().slice(0, 10)}"></div><div><label>Canal</label><select name="canal">${Object.entries(CAN).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div><div><label>Investimento (R$)</label><input name="investimento" inputmode="decimal"></div><div><label>Receita (R$)</label><input name="receita" inputmode="decimal"></div><div><label>Impressões</label><input name="impressoes" inputmode="numeric"></div><div><label>Cliques</label><input name="cliques" inputmode="numeric"></div><div><label>Leads</label><input name="leads" inputmode="numeric"></div><div><label>Conversões</label><input name="conversoes" inputmode="numeric"></div></div><label>Observação (opcional)</label><input name="obs" maxlength="200"><p class="err"></p><button class="btn">Salvar lançamento</button></form>
    <h2>Últimos lançamentos</h2>${L.length ? '<div class="card scroll"><table><tr><th>Data</th><th>Canal</th><th>Invest.</th><th>Leads</th><th>Receita</th><th></th></tr>' + L.slice(0, 30).map(x => `<tr><td>${new Date(x.data + 'T12:00').toLocaleDateString('pt-BR')}</td><td>${CAN[x.canal]}</td><td>${BRL(x.investimento)}</td><td>${x.leads}</td><td>${BRL(x.receita)}</td><td><button class="btn g s d" data-a="mdel" data-v="${x.id}" aria-label="Excluir lançamento">×</button></td></tr>`).join('') + '</table></div>' : '<p class="muted">Nenhum lançamento ainda.</p>'}`;
  },
  corpo: async () => {await loadEx(); return corpoHtml()},
  async lib() {
    await loadEx();
    return `<h1>Biblioteca</h1><div class="row" style="margin:10px 0"><input id="q" placeholder="Buscar exercício" aria-label="Buscar" style="max-width:280px"><select id="gf" aria-label="Grupo" style="max-width:220px"><option value="">Todos os grupos</option>${Object.entries(G).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>${me.role == 'admin' ? '<details class="card" style="margin-bottom:12px"><summary>Importar vídeos oficiais em lote</summary><form data-f="vidlote" style="margin-top:8px"><p class="muted">Uma linha por exercício: nome;link do YouTube</p><textarea name="lista" rows="6" placeholder="Agachamento livre;https://youtu.be/..."></textarea><p class="err"></p><button class="btn">Importar</button></form></details>' : ''}<div id="exl" class="grid">${exl()}</div>`;
  },
  async hoje() {
    const pl = await run(sb.from('plans').select('id,nome,plan_days(id,nome,ordem,plan_items(id,ordem,series,repeticoes,carga,descanso_s,observacao,bloco,tipo_serie,biset_grupo,biset_ordem,exercises(id,nome,grupo_principal,execucao,cuidado,youtube_id,exercise_muscles(musculo,tipo))))').eq('aluno_id', me.id).order('criado_em', {ascending: false}).limit(1));
    if (!pl.length || !pl[0].plan_days.length) return `<h1>Olá, ${esc(me.nome.split(' ')[0])}</h1>` + empty('Sem ficha atribuída', 'Seu personal ainda não atribuiu uma ficha.');
    const p = pl[0], days = [...p.plan_days].sort((a, b) => a.ordem - b.ordem);
    const {count} = await sb.from('workout_logs').select('id', {count: 'exact', head: true}).eq('plan_id', p.id).eq('aluno_id', me.id);
    const d = days[(count || 0) % days.length], items = [...d.plan_items].sort((a, b) => a.ordem - b.ordem);
    cur = {plan: p.id, day: d.nome, items, sets: {}}; WT.t0 = 0; clearInterval(WT.i);
    return `<h1>Olá, ${esc(me.nome.split(' ')[0])}</h1><p class="muted">${esc(p.nome)} · treino ${(count || 0) + 1}</p><h2>${esc(d.nome)}</h2><div class="row"><span id="prog" class="tag n">0 de ${items.reduce((a, x) => a + x.series, 0)} séries</span><span id="wt" class="tag">Tempo 00:00</span></div><div class="list" style="margin-top:10px">${items.map((it, i) => `${(i && items[i - 1].bloco == it.bloco) || !it.bloco ? '' : `<h2>${BLOCO[it.bloco]}</h2>`}<div class="card"><div class="row" style="justify-content:space-between"><h3>${esc(it.exercises.nome)}</h3><span class="tag">${it.biset_ordem ? 'Bi-set ' + it.biset_ordem : G[it.exercises.grupo_principal] || ''}</span></div><p class="muted">${it.series} séries × ${esc(it.repeticoes)} reps · ${it.biset_ordem == 'A1' ? 'sem descanso até o A2' : 'descanso ' + (it.descanso_s ?? 60) + 's'}</p>${det(it.exercises)}${it.observacao ? `<p>${esc(it.observacao)}</p>` : ''}<div id="vd${i}"></div><div class="row" style="margin-top:8px"><input class="ld" style="width:120px" inputmode="decimal" placeholder="Carga (kg)" aria-label="Carga em kg" value="${it.carga ?? ''}">${vidBtn(it.exercises, i)}</div><div class="row" style="margin-top:8px">${Array.from({length: it.series}, (_, j) => `<button class="btn g s" data-a="set" data-v="${i}-${j}" data-r="${it.descanso_s ?? 60}" aria-pressed="false">Série ${j + 1}${String(it.repeticoes).split('/').length > 1 ? ' · ' + esc(String(it.repeticoes).split('/')[j] || '') : ''}</button>`).join('')}</div></div>`).join('')}</div><button class="btn" style="margin-top:14px" data-a="finish">Concluir treino</button>`;
  },
  async evol() {
    const [logs, av] = await Promise.all([
      run(sb.from('workout_logs').select('id,dia,concluido_em,duracao_s').eq('aluno_id', me.id).order('concluido_em', {ascending: false}).limit(120)),
      run(sb.from('assessments').select('id,data,peso,altura,gordura,observacao').eq('aluno_id', me.id).order('data', {ascending: false}))]);
    const W7 = 6048e5, wkc = [5, 4, 3, 2, 1, 0].map(w => logs.filter(l => {const t = Date.now() - new Date(l.concluido_em); return t >= w * W7 && t < (w + 1) * W7}).length);
    return `<h1>Evolução</h1><div class="card"><p class="muted">Treinos por semana · ${logs.length} registrados</p>${bars(wkc, ['-5s', '-4s', '-3s', '-2s', '-1s', 'Esta'])}</div><h2>Histórico</h2>${logs.length ? '<div class="list">' + logs.map(l => `<div class="card row" style="justify-content:space-between"><b>${esc(l.dia)}</b><span class="muted">${l.duracao_s ? Math.round(l.duracao_s / 60) + ' min · ' : ''}${new Date(l.concluido_em).toLocaleString('pt-BR')}</span></div>`).join('') + '</div>' : '<p class="muted">Nenhum treino registrado ainda.</p>'}<h2>Avaliações</h2>${tabAv(av)}`;
  },
  async alunos() {
    const L = await mine(), ids = L.map(x => x.id);
    const [logs, pls] = ids.length ? await Promise.all([
      run(sb.from('workout_logs').select('aluno_id,concluido_em').in('aluno_id', ids).order('concluido_em', {ascending: false}).limit(300)),
      run(sb.from('plans').select('aluno_id').in('aluno_id', ids))]) : [[], []];
    const head = `<h1>Alunos</h1><div class="card" style="margin-bottom:12px"><h3>Seu código de convite</h3><p style="font:800 30px 'Barlow Condensed';color:var(--n)">${esc(me.codigo_convite || '—')}</p><p class="muted">Passe este código ao aluno ou envie o link abaixo: ele abre o cadastro com o código já preenchido.</p><input readonly value="${esc(location.origin + '/?convite=' + (me.codigo_convite || ''))}" aria-label="Link de convite"></div>`;
    if (!L.length) return head + empty('Nenhum aluno vinculado', 'Compartilhe seu código de convite para vincular alunos.');
    return head + '<div class="list">' + L.map(a => {
      const my = logs.filter(l => l.aluno_id == a.id), sem = my.filter(l => Date.now() - new Date(l.concluido_em) < 6048e5).length;
      return `<div class="card"><div class="row" style="justify-content:space-between"><b>${esc(a.nome)}</b><span class="tag ${sem ? 'n' : ''}">${sem} treino(s) em 7 dias</span></div><small class="muted">${esc(a.email)} · ${my.length ? 'último treino ' + new Date(my[0].concluido_em).toLocaleDateString('pt-BR') : 'sem treinos'} · ${pls.some(p => p.aluno_id == a.id) ? 'com ficha' : 'sem ficha'}</small><div class="row" style="margin-top:10px"><button class="btn s" data-a="fb" data-v="${a.id}" data-n="${esc(a.nome)}">Fullbody oficial</button><button class="btn g s" data-a="nf" data-v="${a.id}">Nova ficha</button><button class="btn g s" data-a="av" data-v="${a.id}">Avaliação</button></div></div>`;
    }).join('') + '</div>';
  },
  async aval() {
    const L = await mine(), sel = B?.avAluno || '';
    const av = sel ? await run(sb.from('assessments').select('id,data,peso,altura,gordura,observacao').eq('aluno_id', sel).order('data', {ascending: false})) : [];
    return `<h1>Avaliações físicas</h1>` + (!L.length ? empty('Nenhum aluno vinculado', 'Compartilhe seu código de convite para vincular alunos.') : `<form class="card" data-f="aval"><label>Aluno</label><select name="aluno" data-a="avsel">${opts(L, sel)}</select><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(110px,1fr))"><div><label>Peso (kg)</label><input name="peso" inputmode="decimal"></div><div><label>Altura (cm)</label><input name="altura" inputmode="decimal"></div><div><label>Gordura (%)</label><input name="gordura" inputmode="decimal"></div></div><label>Observações</label><textarea name="obs" rows="2"></textarea><p class="err"></p><button class="btn">Registrar avaliação</button></form>${sel ? '<h2>Histórico</h2>' + tabAv(av) : ''}`);
  },
  async ficha() {
    await loadEx(); const L = await mine();
    if (!B || !B.days) B = {...(B || {}), aluno: B?.aluno || '', nome: '', d: 0, days: [{nome: 'Treino A', items: []}]};
    if (!L.length) return `<h1>Nova ficha</h1>` + empty('Nenhum aluno vinculado', 'Compartilhe seu código de convite para vincular alunos.');
    const D = B.days[B.d];
    return `<h1>Nova ficha</h1><div class="card"><div class="grid"><div><label>Aluno</label><select data-k="aluno">${opts(L, B.aluno)}</select></div><div><label>Nome da ficha</label><input data-k="nome" value="${esc(B.nome)}"></div></div><div class="row" style="margin:12px 0">${B.days.map((x, i) => `<button class="btn s ${i == B.d ? '' : 'g'}" data-a="day" data-v="${i}">${esc(x.nome)}</button>`).join('')}<button class="btn g s" data-a="addday">+ Dia</button></div>${D.items.map((it, i) => `<div class="card" style="margin-bottom:8px"><div class="row" style="justify-content:space-between"><b>${esc(EX.find(e => e.id == it.ex)?.nome)}</b><button class="btn g s d" data-a="rm" data-v="${i}">Remover</button></div><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(90px,1fr))">${[['s', 'Séries'], ['r', 'Reps'], ['rest', 'Descanso (s)']].map(([k, l]) => `<div><label>${l}</label><input data-i="${i}" data-key="${k}" value="${esc(it[k])}"></div>`).join('')}</div><input data-i="${i}" data-key="obs" placeholder="Orientações" aria-label="Orientações" value="${esc(it.obs)}" style="margin-top:8px"></div>`).join('') || '<p class="muted">Dia vazio. Adicione exercícios.</p>'}<div class="row" style="margin-top:10px"><select id="pick" style="max-width:280px">${EX.map(e => `<option value="${e.id}">${esc(e.nome)}</option>`).join('')}</select><button class="btn g" data-a="padd">Adicionar exercício</button></div><p class="err" id="de"></p><div class="row"><button class="btn" data-a="save">Atribuir ficha</button><button class="btn g" data-a="clear">Limpar</button></div></div>`;
  },
  async usu() {
    const L = await run(sb.from('profiles').select('id,nome,email,telefone,role,ativo,criado_em').order('criado_em', {ascending: false}));
    return `<h1>Usuários</h1><div class="card scroll"><table><tr><th>Nome</th><th>E-mail</th><th>Telefone</th><th>Perfil</th><th>Status</th></tr>${L.map(u => `<tr><td>${esc(u.nome)}</td><td>${esc(u.email)}</td><td>${esc(u.telefone || '-')}</td><td><select data-a="role" data-id="${u.id}" ${u.id == me.id && !me.superadmin ? 'disabled' : ''}>${Object.entries(ROLE).map(([k, v]) => `<option value="${k}" ${k == u.role ? 'selected' : ''}>${v}</option>`).join('')}</select></td><td><button class="btn g s" data-a="ativo" data-id="${u.id}" data-v="${u.ativo}" ${u.id == me.id ? 'disabled' : ''}>${u.ativo ? 'Desativar' : 'Ativar'}</button></td></tr>`).join('')}</table></div>`;
  },
  async vinc() {
    const [P, ts] = await Promise.all([run(sb.from('profiles').select('id,nome,role').order('nome')), run(sb.from('trainer_students').select('personal_id,aluno_id'))]);
    const nm = id => esc(P.find(p => p.id == id)?.nome);
    return `<h1>Vínculos</h1><form class="card" data-f="vinc"><div class="grid"><div><label>Personal</label><select name="personal">${opts(P.filter(p => p.role == 'personal'))}</select></div><div><label>Aluno</label><select name="aluno">${opts(P.filter(p => p.role == 'aluno'))}</select></div></div><p class="err"></p><button class="btn">Criar vínculo</button></form><h2>Vínculos existentes</h2>${ts.length ? '<div class="list">' + ts.map(t => `<div class="card row" style="justify-content:space-between"><span>${nm(t.personal_id)} → ${nm(t.aluno_id)}</span><button class="btn g s d" data-a="unlink" data-p="${t.personal_id}" data-v="${t.aluno_id}">Remover</button></div>`).join('') + '</div>' : '<p class="muted">Nenhum vínculo.</p>'}`;
  }
};
const tabAv = L => L.length ? `<div class="card scroll"><table><tr><th>Data</th><th>Peso</th><th>Altura</th><th>Gordura</th><th>Obs.</th></tr>${L.map(a => `<tr><td>${new Date(a.data + 'T12:00').toLocaleDateString('pt-BR')}</td><td>${a.peso ?? '-'}</td><td>${a.altura ?? '-'}</td><td>${a.gordura ?? '-'}</td><td>${esc(a.observacao)}</td></tr>`).join('')}</table></div>` : '<p class="muted">Nenhuma avaliação registrada.</p>';

const hojeBase = V.hoje;
V.hoje = async () => {
  const lk = await run(sb.from('trainer_students').select('personal_id').eq('aluno_id', me.id).eq('ativo', true).limit(1));
  const form = lk.length ? '' : '<form class="card" data-f="convite" style="margin-bottom:12px"><h3>Vincule-se ao seu personal</h3><p class="muted">Peça o código ao seu personal e digite abaixo.</p><input name="codigo" placeholder="Código (ex.: A1B2C3D4)" autocapitalize="characters" aria-label="Código do personal"><p class="err"></p><button class="btn">Vincular</button></form>';
  return form + await hojeBase();
};

/* ---------- Ações ---------- */
const rt = () => {const e = $('#tm'); if (!e) return; e.hidden = !T.l; e.innerHTML = T.l ? `<svg width="56" height="56" viewBox="0 0 36 36" aria-hidden="true"><circle cx="18" cy="18" r="15" fill="none" stroke="#2a2d31" stroke-width="3"/><circle cx="18" cy="18" r="15" fill="none" stroke="#39ff14" stroke-width="3" stroke-linecap="round" stroke-dasharray="${94.2 * T.l / (T.t || 1)} 94.2" transform="rotate(-90 18 18)"/></svg><span>Descanso <b>${Math.floor(T.l / 60)}:${String(T.l % 60).padStart(2, '0')}</b></span><button class="btn g s" data-a="tadd">+15s</button><button class="btn s" data-a="tstop">Pular</button>` : ''};
const A = {
  mode: d => authView('', d.v),
  async vid(d) {
    const e = EX.find(x => x.id == d.v); if (!e) return;
    const adm = me.role == 'admin', cur = adm ? e.youtube_id : PV[e.id];
    const inp = prompt((adm ? 'Vídeo OFICIAL' : 'Seu vídeo') + ' de "' + e.nome + '".\nCole o link do YouTube (deixe vazio para remover):', cur ? 'https://youtu.be/' + cur : '');
    if (inp === null) return;
    const v = inp.trim(), id = v ? ytId(v) : null;
    if (v && !id) return toast('Link inválido. Use um link do YouTube (youtu.be, watch?v= ou shorts).');
    if (adm) {const r = await run(sb.from('exercises').update({youtube_id: id}).eq('id', e.id).select('id')); if (!r.length) return toast('Sem permissão para alterar o vídeo oficial.'); e.youtube_id = id}
    else if (id) {await run(sb.from('personal_videos').upsert({exercise_id: e.id, personal_id: me.id, youtube_id: id}, {onConflict: 'exercise_id,personal_id'})); PV[e.id] = id}
    else {await run(sb.from('personal_videos').delete().eq('exercise_id', e.id).eq('personal_id', me.id)); delete PV[e.id]}
    toast(id ? 'Vídeo salvo' : 'Vídeo removido'); const el = $('#exl'); if (el) el.innerHTML = exl();
  },
  async mdel(d) {if (!confirm('Excluir este lançamento?')) return; await run(sb.from('marketing_entries').delete().eq('id', d.v)); view()},
  async fb(d, el) {
    if (!confirm('Atribuir o Fullbody oficial ROI SHAPE a ' + d.n + '? As cargas ficam em branco para você definir.')) return;
    el.disabled = true;
    try {
      const m = await run(sb.from('workout_models').select('id').eq('ativo', true).order('publicado_em', {ascending: false}).limit(1));
      if (!m.length) {toast('Nenhum modelo oficial publicado.'); el.disabled = false; return}
      await run(sb.rpc('assign_model', {p_aluno: d.v, p_modelo: m[0].id}));
      toast('Fullbody oficial atribuído'); view();
    } catch (e) {el.disabled = false}
  },
  nf: d => {B = {...(B || {}), aluno: d.v, nome: '', d: 0, days: [{nome: 'Treino A', items: []}]}; tab = 'ficha'; view()},
  av: d => {B = {...(B || {}), avAluno: d.v}; tab = 'aval'; view()},
  mu: d => {bMu = d.v; $('#main').innerHTML = corpoHtml()},
  bview: d => {bView = d.v; bMu = ''; $('#main').innerHTML = corpoHtml()},
  addex: d => {if (!B || !B.days) B = {...(B || {}), aluno: B?.aluno || '', nome: '', d: 0, days: [{nome: 'Treino A', items: []}]}; B.days[B.d].items.push({ex: d.v, s: 3, r: '10-12', rest: 60, obs: ''}); toast('Adicionado em ' + B.days[B.d].nome + ' (aba Fichas)')},
  async modo(d, el) {
    const {data, error} = await sb.from('profiles').update({role: el.value}).eq('id', me.id).select('*').single();
    if (error) {toast('Não foi possível trocar o modo: ' + error.message); return view()}
    me = data; tab = TABS[me.role][0][0]; shell(); toast('Modo de teste: ' + ROLE[me.role]);
  },
  async google() {
    try {localStorage.setItem('convite', CONV)} catch (e) {}
    const {error} = await sb.auth.signInWithOAuth({provider: 'google', options: {redirectTo: location.origin}});
    if (error) toast('Não foi possível iniciar o login com Google: ' + error.message);
  },
  out: async () => {await sb.auth.signOut(); me = null; B = null},
  tab: d => {tab = d.v; view()},
  set: (d, el) => {const on = el.getAttribute('aria-pressed') != 'true'; el.setAttribute('aria-pressed', on); el.classList.toggle('g', !on); if (on && !WT.t0) {WT.t0 = Date.now(); WT.i = setInterval(wtTick, 1000)} cur.sets[d.v] = on; const pr = $('#prog'); if (pr) pr.textContent = Object.values(cur.sets).filter(Boolean).length + ' de ' + cur.items.reduce((a, x) => a + x.series, 0) + ' séries'; if (on && +d.r > 0) {clearInterval(T.i); T.l = T.t = +d.r || 60; T.i = setInterval(() => {if (--T.l <= 0) {clearInterval(T.i); T.l = 0; navigator.vibrate?.(300); toast('Descanso finalizado')} rt()}, 1000); rt()}},
  tadd: () => {T.l += 15; T.t += 15; rt()},
  play(d) {const box = $('#vd' + d.i); if (!box) return; box.innerHTML = box.innerHTML ? '' : `<div class="vid"><iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(d.v)}?rel=0&playsinline=1" title="Vídeo do exercício" loading="lazy" allow="encrypted-media; picture-in-picture; fullscreen" allowfullscreen></iframe></div>`},
  tstop: () => {clearInterval(T.i); T.l = 0; rt()},
  async finish(d, el) {
    const lds = [...document.querySelectorAll('.ld')].map(x => x.value.trim());
    const done = cur.items.map((it, i) => Array.from({length: it.series}, (_, j) => cur.sets[i + '-' + j]).filter(Boolean).length);
    if (!done.some(n => n)) return toast('Marque ao menos uma série como feita.');
    if (lds.some(v => v && !(num(v) >= 0))) return toast('Carga inválida: use apenas números.');
    el.disabled = true;
    try {
      const log = await run(sb.from('workout_logs').insert({aluno_id: me.id, plan_id: cur.plan, dia: cur.day, duracao_s: WT.t0 ? Math.min(43200, Math.round((Date.now() - WT.t0) / 1000)) : null}).select('id').single());
      const rows = []; cur.items.forEach((it, i) => {for (let j = 0; j < it.series; j++) if (cur.sets[i + '-' + j]) rows.push({log_id: log.id, exercise_id: it.exercises.id, serie: j + 1, carga: num(lds[i])})});
      await run(sb.from('set_logs').insert(rows));
      clearInterval(WT.i); WT.t0 = 0; toast('Treino registrado. Bom trabalho!'); view();
    } catch (e) {el.disabled = false}
  },
  avsel: (d, el) => {B = {...(B || {}), avAluno: el.value}; view()},
  day: d => {B.d = +d.v; view()},
  addday: () => {B.days.push({nome: 'Treino ' + 'ABCDEFG'[B.days.length], items: []}); B.d = B.days.length - 1; view()},
  padd: () => {B.days[B.d].items.push({ex: $('#pick').value, s: 3, r: '10-12', rest: 60, obs: ''}); view()},
  rm: d => {B.days[B.d].items.splice(+d.v, 1); view()},
  clear: () => {B = null; view()},
  async save(d, el) {
    const e = $('#de'); e.textContent = '';
    if (!B.aluno) return e.textContent = 'Selecione o aluno.';
    if (!B.nome.trim()) return e.textContent = 'Dê um nome à ficha.';
    const days = B.days.filter(x => x.items.length);
    if (!days.length) return e.textContent = 'Adicione ao menos um exercício.';
    for (const x of days) for (const it of x.items) {
      const s = num(it.s), r = num(it.rest);
      if (!(Number.isInteger(s) && s >= 1 && s <= 20)) return e.textContent = 'Séries devem ser um número de 1 a 20.';
      if (!(Number.isInteger(r) && r >= 0 && r <= 900)) return e.textContent = 'Descanso deve ser um número de 0 a 900 segundos.';
      if (!String(it.r).trim() || String(it.r).length > 20) return e.textContent = 'Informe as repetições (até 20 caracteres).';
    }
    el.disabled = true;
    try {
      const dias = days.map(x => ({nome: x.nome, itens: x.items.map(it => ({exercise_id: it.ex, series: num(it.s), repeticoes: String(it.r).trim(), descanso_s: num(it.rest), observacao: it.obs?.trim() || ''}))}));
      await run(sb.rpc('create_plan', {p_aluno: B.aluno, p_nome: B.nome.trim(), p_dias: dias}));
      B = null; toast('Ficha atribuída ao aluno'); view();
    } catch (x) {el.disabled = false}
  },
  async role(d, el) {const {error} = await sb.from('profiles').update({role: el.value}).eq('id', el.dataset.id); toast(error ? 'Erro: ' + error.message : 'Perfil atualizado'); view()},
  async ativo(d, el) {const {error} = await sb.from('profiles').update({ativo: d.v != 'true'}).eq('id', d.id); toast(error ? 'Erro: ' + error.message : 'Status atualizado'); view()},
  async unlink(d) {if (!confirm('Remover este vínculo?')) return; await run(sb.from('trainer_students').delete().eq('personal_id', d.p).eq('aluno_id', d.v)); view()}
};

/* ---------- Eventos ---------- */
document.addEventListener('click', e => {const b = e.target.closest('[data-a]'); if (!b || ['SELECT', 'INPUT'].includes(b.tagName)) return; e.preventDefault(); A[b.dataset.a]?.(b.dataset, b)});
document.addEventListener('submit', e => {e.preventDefault(); const f = e.target; F[f.dataset.f]?.(Object.fromEntries(new FormData(f)), f)});
document.addEventListener('input', e => {if (e.target.id == 'q' || e.target.id == 'gf') $('#exl').innerHTML = exl()});
document.addEventListener('change', e => {
  const t = e.target;
  if (t.id == 'showpw') {document.querySelectorAll('input[name=senha]').forEach(i => {i.type = t.checked ? 'text' : 'password'}); return}
  if (t.dataset.a && t.tagName == 'SELECT') return A[t.dataset.a](t.dataset, t);
  if (B && t.dataset.k) B[t.dataset.k] = t.value;
  else if (B && t.dataset.key) B.days[B.d].items[+t.dataset.i][t.dataset.key] = t.value;
});
document.addEventListener('keydown', e => {if ((e.key == 'Enter' || e.key == ' ') && e.target.classList?.contains('mu')) {e.preventDefault(); e.target.dispatchEvent(new Event('click', {bubbles: true}))}});
document.addEventListener('focusin', e => {if (e.target.matches?.('input[readonly]')) e.target.select()});
sb.auth.onAuthStateChange((ev, s) => {
  if (ev == 'PASSWORD_RECOVERY') return recoveryView();
  if (['INITIAL_SESSION', 'SIGNED_IN', 'SIGNED_OUT'].includes(ev)) setTimeout(() => boot(s), 0);
});
