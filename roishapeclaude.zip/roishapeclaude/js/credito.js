import {RESP_TECNICO as R} from './config.js';
const el = document.getElementById('credito');
if (el && R.cref) {
  el.append('Método ROI SHAPE idealizado por ' + R.nome + ', responsável técnico · Profissional de Educação Física · CREF ' + R.cref + ' · ');
  const a = document.createElement('a'); a.href = 'https://www.confef.org.br/'; a.target = '_blank'; a.rel = 'noopener'; a.textContent = 'Consultar registro';
  el.append(a);
}
